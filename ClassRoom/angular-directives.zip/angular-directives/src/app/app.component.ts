import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { MyCustomStyleDirective } from './my-custom-style.directive';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, MyCustomStyleDirective],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  // title = 'angular-directives';

  // flag = true;
  // // msg = false;

  // myStyleProp = "purple"

  // textColor = "red"

  // superHero = 'wond';

  // classProp = "c3"

  // employees = [
  //   {
  //     empId: 123,
  //     empName: 'rahul',
  //     empCity: 'kolkata',
  //   },
  //   {
  //     empId: 142,
  //     empName: 'sudeer',
  //     empCity: 'unknown',
  //   },
  //   {
  //     empId: 243,
  //     empName: 'harsh',
  //     empCity: 'punjab',
  //   },
  //   {
  //     empId: 634,
  //     empName: 'umang',
  //     empCity: 'delhi',
  //   },
  // ];











  
}
