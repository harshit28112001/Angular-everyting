import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appMyCustomStyle]',
  standalone: true,
})
export class MyCustomStyleDirective {

  constructor(private ele: ElementRef) {
    console.log(ele);
    ele.nativeElement.style.color = 'orange';
  }

  
}
