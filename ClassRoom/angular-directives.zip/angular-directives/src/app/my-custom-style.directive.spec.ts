import { MyCustomStyleDirective } from './my-custom-style.directive';

describe('MyCustomStyleDirective', () => {
  it('should create an instance', () => {
    const directive = new MyCustomStyleDirective();
    expect(directive).toBeTruthy();
  });
});
