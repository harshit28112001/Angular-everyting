import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { ChildComponent } from './components/child/child.component';
import { HeaderComponent } from './components/header/header.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, ChildComponent, HeaderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements AfterViewInit {
  userLoggedIn: boolean;

  @ViewChild(ChildComponent) childComponentsRef: ChildComponent;

  ngAfterViewInit(): void {
    // this.childComponentsRef.name = 'qwdasdsa';
  }

  greetMe(val: string) {
    alert('Hello : ' + val);
  }
}
