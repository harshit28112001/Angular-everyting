import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';

@Component({
  selector: 'app-child',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './child.component.html',
  styleUrl: './child.component.css',
})
export class ChildComponent implements OnChanges {
  @Input()
  loggedIn: boolean;
  message: string;

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);

    const loggedValue = changes['loggedIn'];
    if (loggedValue.currentValue === true) {
      this.message = 'Welcome Back';
    } else {
      this.message = 'Please log in';
    }
  }

  

  greetZaid() {
    alert('Hello ');
  }




  name = 'Zaid';
  @Output() greetEvent = new EventEmitter();

  callParentGreetFromChild() {
    this.greetEvent.emit(this.name)
  }












  // get loggedIn(): boolean
  // {
  //   return this._loggedIn
  // }

  // @Input()
  // public set loggedIN(value : boolean) {
  //  this._loggedIn = value;
  //  if(value === true)
  //  {
  //   this.message = "Welcome Back"
  //  }
  //  else{
  //   this.message = "Please log in"
  //  }
  // }
}
